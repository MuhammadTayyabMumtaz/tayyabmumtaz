// Wait for the DOM to load
document.addEventListener("DOMContentLoaded", function () {
    // Initialize Typed.js for the Home Section
    var typedHome = new Typed('.home .multiple-text', {
        strings: ['Web Developer', 'Web Designer', 'Freelancer', 'Account Manager'], // Add your desired texts here
        typeSpeed: 50, // Typing speed in milliseconds
        backSpeed: 40, // Backspacing speed in milliseconds
        backDelay: 800, // Delay before backspacing
        loop: true // Loop the animation
    });

    // Initialize Typed.js for the About Section
    var typedAbout = new Typed('.about .multiple-text', {
        strings: ['Web Developer', 'Web Designer', 'Freelancer', 'Account Manager'], // Add your desired texts here
        typeSpeed: 50, // Typing speed in milliseconds
        backSpeed: 400, // Backspacing speed in milliseconds
        backDelay: 800, // Delay before backspacing
        loop: true // Loop the animation
    });

    // Your existing code (if any) goes here
    // For example, menu toggle functionality or other scripts
    const menuIcon = document.getElementById('menu-icon');
    const navbar = document.querySelector('.navbar');

    if (menuIcon && navbar) {
        menuIcon.addEventListener('click', () => {
            navbar.classList.toggle('active');
        });
    }
});